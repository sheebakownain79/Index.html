// Show project details

function showDetails(projectName) {

  alert("More details about " + projectName + " will appear here!");

}

// Contact form simulation

function sendMessage(event) {

  event.preventDefault();

  document.getElementById("form-status").innerText =

    "Thank you for your message! I will get back to you soon.";

  event.target.reset();

}